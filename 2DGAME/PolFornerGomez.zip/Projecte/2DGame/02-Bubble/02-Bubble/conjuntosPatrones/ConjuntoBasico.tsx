<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ConjuntoBasico" tilewidth="64" tileheight="64" tilecount="64" columns="8">
 <image source="../images/tileset64.png" width="512" height="512"/>
</tileset>
